WHAT WORKS AND WHAT DOESN'T

Main Character Walking: Works
Battle Animation: Doesn't Work
Evolution: Doesn't Work
Entering/Exiting Building Animation: Works

Character Sprites: Works
Capture/Nickname System: NEED
Shopping/Healing System: NEED
Background Picture: Works
Sound Effects: NEED
Action Animations: NEED
Area Indication: NEED
Area/Object Collision System: NEED
Character/Speech Matchup: NEED
Level Up Stats/Math: NEED
Side Menu: Works
    Pokedex System: NEED
        Pokemon/Information Matchup: NEED
    Pokemon Party System: NEED
    Bag System: NEED
    Player Card System: NEED
    Save System: NEED
    Options: NEED